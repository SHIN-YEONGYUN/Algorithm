package day5_이론;

public class Ex03_ParseInt {

	public static void main(String[] args) {
		String str = "123.222";
		System.out.println(str);
		System.out.println(Double.parseDouble(str));
	}

}
