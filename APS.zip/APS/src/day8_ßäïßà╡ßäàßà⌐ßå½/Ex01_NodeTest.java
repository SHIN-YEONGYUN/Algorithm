package day8_이론;

public class Ex01_NodeTest {
	public static void main(String[] args) {

		// 생성자를 통해서 int값이 들어오면, data에 int값을 할당, link는

		Node myNode = new Node(3);
		Node myNode2 = new Node(156);
		System.out.println(myNode);
		System.out.println(myNode2);
		
		// 노드는 만들었으니, 링크를 만들어보자
	}
}
