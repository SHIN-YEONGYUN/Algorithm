package day1_기초;

public class Break {

	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.print((i + 1) + " ");
			if (i == 2) {
				break;
			}
		}

	}

}
