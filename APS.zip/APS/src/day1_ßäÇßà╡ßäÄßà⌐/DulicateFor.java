package day1_기초;

public class DulicateFor {

	public static void main(String[] args) {
		for(int i=0; i<3; i++) {
			System.out.println(i);
			for(int j=10; j<13; j++) {
				System.out.println("    "+j);
			}
		}

	}

}
