package day1_기초;

public class While {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
			// System.out.println(i);
			//System.out.print(i + " ");
		}
		int j = 1;

		while (j < 11) {
			System.out.print(j + " ");
			j = j + 1;
		}

	}

}
